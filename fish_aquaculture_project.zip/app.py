from flask import Flask, render_template, request
import os
from model import predict_fish

app = Flask(__name__)
UPLOAD_FOLDER = "static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        file = request.files["file"]
        if file:
            filepath = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(filepath)
            results = predict_fish(filepath)
            labels = results[0].boxes.cls.cpu().numpy()
            num_fish = len(labels)
            return render_template("index.html", filepath=filepath, num_fish=num_fish)
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
