from ultralytics import YOLO

model = YOLO("yolov8n.pt")

def predict_fish(image_path):
    results = model(image_path)
    return results
